# ╔══════════════════════════════════════════════════════════════════════════╗
# ║   TRIKALA DARSHANA · त्रिकाल दर्शन                                      ║
# ║   Step 8: Testing with Real Indian Startups                             ║
# ║   Trained on Failure. Built for Survival.                               ║
# ╚══════════════════════════════════════════════════════════════════════════╝

import pandas as pd
import numpy as np
import joblib, json
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import warnings
warnings.filterwarnings('ignore')

print("=" * 65)
print("  🪔 TRIKALA DARSHANA — Real Startup Testing")
print("=" * 65)

# ─────────────────────────────────────────────────────────────────
# LOAD MODEL
# ─────────────────────────────────────────────────────────────────
model    = joblib.load('/home/claude/trikala_rf_model.pkl')
metadata = json.load(open('/home/claude/trikala_model_metadata.json'))

CITY_MAP = {
    "Bangalore":6,"Mumbai":61,"Delhi":23,"Gurgaon":33,
    "Hyderabad":37,"Chennai":18,"Pune":73,"Noida":67,"Other":0,
}
INDUSTRY_MAP = {
    "E-Commerce":3,"Tech/SaaS":12,"EdTech":2,"FinTech":4,
    "HealthTech":6,"FoodTech":5,"Logistics":8,"Media":9,
    "RealEstate":10,"Services":11,"Other":1,
}
STAGE_MAP = {
    "Pre-seed":1,"Seed":2,"Bridge":3,"Series A":4,
    "Series B":5,"Series C":6,"Late Stage":7,"PE":8,"IPO":9
}

def predict_startup(name, funding, rounds, city, industry, stage,
                    actual_status, description):
    rounds  = max(rounds, 1)
    fpr     = funding / rounds
    log_f   = np.log1p(funding)
    log_fpr = np.log1p(fpr)
    city_e  = CITY_MAP.get(city, 0)
    ind_e   = INDUSTRY_MAP.get(industry, 1)
    stg_e   = STAGE_MAP.get(stage, 2)
    major   = 1 if city in ["Bangalore","Mumbai","Delhi","Hyderabad","Chennai","Pune"] else 0
    tech    = 1 if industry in ["Tech/SaaS","EdTech","FinTech","HealthTech","E-Commerce"] else 0
    if funding == 0:       band = 0
    elif funding < 1e5:    band = 1
    elif funding < 5e5:    band = 2
    elif funding < 2e6:    band = 3
    elif funding < 1e7:    band = 4
    else:                  band = 5

    feats = pd.DataFrame([[
        funding, rounds, fpr, log_f, log_fpr,
        stg_e, city_e, ind_e, major, tech, band
    ]], columns=[
        'TotalFunding','FundingRounds','FundingPerRound',
        'LogFunding','LogFundingPerRound','StageEncoded',
        'CityEncoded','IndustryEncoded','IsMajorCity',
        'IsTechIndustry','FundingBand'
    ])

    code  = model.predict(feats)[0]
    proba = model.predict_proba(feats)[0]
    pred  = "Safe" if code == 1 else "Failed"
    conf  = proba[code] * 100
    correct = "✅" if pred.lower() == actual_status.lower() else "❌"

    return {
        "name"          : name,
        "prediction"    : pred,
        "confidence"    : conf,
        "actual"        : actual_status,
        "correct"       : correct,
        "description"   : description,
        "funding_m"     : funding/1e6,
        "city"          : city,
        "industry"      : industry,
        "stage"         : stage,
    }

# ─────────────────────────────────────────────────────────────────
# 12 REAL INDIAN STARTUPS
# ─────────────────────────────────────────────────────────────────
# Format: name, funding($), rounds, city, industry, stage, actual, description
test_cases = [
    # ── SUCCESSFUL STARTUPS ──────────────────────────────────
    ("Zepto",       900_000_000, 6, "Mumbai",    "E-Commerce", "Series C",  "Safe",   "Quick commerce unicorn, $900M raised"),
    ("Razorpay",    741_500_000, 7, "Bangalore", "FinTech",    "Late Stage","Safe",   "Payments unicorn, $7.5B valuation"),
    ("CRED",        800_000_000, 6, "Bangalore", "FinTech",    "Series E",  "Safe",   "Credit card rewards platform, unicorn"),
    ("Unacademy",   440_000_000, 8, "Bangalore", "EdTech",     "Series F",  "Safe",   "EdTech unicorn, $3.4B valuation"),
    ("Meesho",      570_000_000, 7, "Bangalore", "E-Commerce", "Series F",  "Safe",   "Social commerce platform, unicorn"),
    ("Ola",       3_800_000_000, 9, "Bangalore", "Logistics",  "Late Stage","Safe",   "Ride-hailing giant, $7.3B valuation"),

    # ── FAILED / STRUGGLING STARTUPS ─────────────────────────
    ("Koo",           60_000_000, 5, "Bangalore", "Tech/SaaS",  "Series B",  "Failed", "Twitter clone, shut down in 2024"),
    ("Byju's",    5_800_000_000, 9, "Bangalore", "EdTech",     "Late Stage","Failed", "EdTech giant, collapsed under debt"),
    ("PepperTap",     51_200_000, 3, "Gurgaon",   "E-Commerce", "Series B",  "Failed", "Grocery delivery, shut 2016"),
    ("Stayzilla",     33_500_000, 4, "Chennai",   "RealEstate", "Series B",  "Failed", "Homestay platform, shut 2017"),
    ("TinyOwl",       17_200_000, 3, "Mumbai",    "FoodTech",   "Series A",  "Failed", "Food delivery, shut 2016"),
    ("Bluelearn",        500_000, 2, "Mumbai",    "EdTech",     "Seed",      "Failed", "EdTech startup, shut 2023"),
]

# ─────────────────────────────────────────────────────────────────
# RUN ALL TESTS
# ─────────────────────────────────────────────────────────────────
print("\n📋 Testing 12 Real Indian Startups...\n")
print(f"{'Startup':<14} {'Predicted':<10} {'Confidence':>11} {'Actual':<10} {'Match'}")
print("-" * 58)

results = []
for tc in test_cases:
    r = predict_startup(*tc)
    results.append(r)
    print(f"{r['name']:<14} {r['prediction']:<10} {r['confidence']:>9.1f}%  {r['actual']:<10} {r['correct']}")

# ─────────────────────────────────────────────────────────────────
# SCORE
# ─────────────────────────────────────────────────────────────────
correct = sum(1 for r in results if r['correct'] == "✅")
total   = len(results)
score   = correct / total * 100

print(f"\n{'=' * 58}")
print(f"  Test Score: {correct}/{total} correct ({score:.1f}%)")
print(f"  Model Accuracy (test set): {metadata['random_forest']['accuracy']*100:.1f}%")
print(f"{'=' * 58}")

# ─────────────────────────────────────────────────────────────────
# DETAILED REPORT
# ─────────────────────────────────────────────────────────────────
print("\n📊 Detailed Report:\n")
for r in results:
    status_color = "✅ CORRECT" if r['correct'] == "✅" else "❌ WRONG"
    print(f"  {r['name']} ({r['city']} · {r['industry']})")
    print(f"    Predicted : {r['prediction']} ({r['confidence']:.1f}% confidence)")
    print(f"    Actual    : {r['actual']}")
    print(f"    Result    : {status_color}")
    print(f"    Note      : {r['description']}")
    print()

# ─────────────────────────────────────────────────────────────────
# VISUALIZATION
# ─────────────────────────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(16, 6))
fig.patch.set_facecolor('#07060f')
fig.suptitle('🪔 Trikala Darshana — Real Startup Test Results',
             fontsize=14, color='#FFD700', fontweight='bold')

def style_ax(ax, title):
    ax.set_facecolor('#07060f')
    ax.set_title(title, color='#f0e8d8', fontsize=10, pad=8)
    ax.tick_params(colors='#9a8f7a', labelsize=8)
    for sp in ax.spines.values():
        sp.set_edgecolor('#FFC850'); sp.set_alpha(0.2)
    ax.grid(color='#FFC850', linestyle='--', linewidth=0.4, alpha=0.08)

# Plot 1 — Confidence per startup
ax = axes[0]
names  = [r['name'] for r in results]
confs  = [r['confidence'] for r in results]
colors = ['#4caf50' if r['correct']=='✅' else '#ef5350' for r in results]
bars   = ax.barh(names, confs, color=colors, edgecolor='none', height=0.6)
for b, v in zip(bars, confs):
    ax.text(v+0.5, b.get_y()+b.get_height()/2,
            f'{v:.1f}%', va='center', color='#f0e8d8', fontsize=7)
ax.set_xlim(0, 115)
ax.axvline(x=50, color='#FFC850', linewidth=0.8, alpha=0.4, linestyle='--')
correct_p = mpatches.Patch(color='#4caf50', label='Correct')
wrong_p   = mpatches.Patch(color='#ef5350', label='Wrong')
ax.legend(handles=[correct_p, wrong_p], fontsize=7,
          labelcolor='#f0e8d8', facecolor='#07060f', edgecolor='#FFC850')
style_ax(ax, 'Confidence by Startup')

# Plot 2 — Correct vs Wrong
ax2    = axes[1]
c_safe = sum(1 for r in results if r['actual']=='Safe' and r['correct']=='✅')
w_safe = sum(1 for r in results if r['actual']=='Safe' and r['correct']=='❌')
c_fail = sum(1 for r in results if r['actual']=='Failed' and r['correct']=='✅')
w_fail = sum(1 for r in results if r['actual']=='Failed' and r['correct']=='❌')
cats   = ['Safe\n(Correct)', 'Safe\n(Wrong)', 'Failed\n(Correct)', 'Failed\n(Wrong)']
vals   = [c_safe, w_safe, c_fail, w_fail]
clrs   = ['#4caf50', '#ef5350', '#4caf50', '#ef5350']
bars2  = ax2.bar(cats, vals, color=clrs, edgecolor='none', width=0.5, alpha=0.85)
for b, v in zip(bars2, vals):
    ax2.text(b.get_x()+b.get_width()/2, b.get_height()+0.05,
             str(v), ha='center', va='bottom', color='#f0e8d8', fontsize=10)
ax2.set_ylim(0, max(vals)+2)
ax2.set_xticklabels(cats, fontsize=8)
style_ax(ax2, 'Prediction Breakdown')

# Plot 3 — Score gauge
ax3 = axes[2]
ax3.set_facecolor('#07060f')
ax3.set_xlim(-1.5, 1.5); ax3.set_ylim(-1.5, 1.5)
ax3.set_aspect('equal')
for sp in ax3.spines.values(): sp.set_visible(False)
ax3.set_xticks([]); ax3.set_yticks([])

theta  = np.linspace(np.pi, 0, 100)
ax3.plot(np.cos(theta), np.sin(theta), color='#FFC850', linewidth=12, alpha=0.15)
fill_theta = np.linspace(np.pi, np.pi - (score/100)*np.pi, 100)
color_gauge = '#4caf50' if score >= 70 else '#FF9933' if score >= 50 else '#ef5350'
ax3.plot(np.cos(fill_theta), np.sin(fill_theta), color=color_gauge, linewidth=12, alpha=0.85)

ax3.text(0, 0.1,  f'{score:.0f}%', ha='center', va='center',
         color='#FFD700', fontsize=28, fontweight='bold',
         fontfamily='monospace')
ax3.text(0, -0.4, f'{correct}/{total} correct', ha='center', va='center',
         color='#f0e8d8', fontsize=10)
ax3.text(0, -0.75, 'Test Score', ha='center', va='center',
         color='#9a8f7a', fontsize=9)
ax3.set_title('Overall Test Score', color='#f0e8d8', fontsize=10, pad=8)

plt.tight_layout()
plt.savefig('/home/claude/test_results.png', dpi=150, bbox_inches='tight',
            facecolor='#07060f', edgecolor='none')
plt.show()
print("✅ test_results.png saved!")

# ─────────────────────────────────────────────────────────────────
# WRONG PREDICTIONS ANALYSIS
# ─────────────────────────────────────────────────────────────────
wrong = [r for r in results if r['correct'] == '❌']
if wrong:
    print(f"\n⚠️  Wrong Predictions Analysis ({len(wrong)}):")
    for r in wrong:
        print(f"\n  {r['name']}")
        print(f"  Predicted {r['prediction']} but was {r['actual']}")
        print(f"  Why: {r['description']}")
        if r['name'] == "Byju's":
            print(f"  Note: Byju's had massive funding ($5.8B) but collapsed due to")
            print(f"        fraud/mismanagement — financial features alone can't detect this.")
        elif r['name'] == "Koo":
            print(f"  Note: Koo had decent funding but failed due to market competition")
            print(f"        from Twitter — market factors not in dataset.")
else:
    print("\n🎉 All predictions correct!")

# ─────────────────────────────────────────────────────────────────
# FINAL SUMMARY
# ─────────────────────────────────────────────────────────────────
print(f"""
╔══════════════════════════════════════════════════════════════╗
║  TESTING SUMMARY                                             ║
╠══════════════════════════════════════════════════════════════╣
║  Startups tested    : {total}                                        
║  Correct predictions: {correct}                                        
║  Test score         : {score:.1f}%                                   
║  Model accuracy     : {metadata['random_forest']['accuracy']*100:.1f}%                                  
║  Model F1 Score     : {metadata['random_forest']['f1']}                                  
║  Model ROC AUC      : {metadata['random_forest']['roc_auc']}                                  
║                                                              ║
║  ✅ Trikala Darshana is ready for deployment!                ║
║                                                              ║
║  Files ready:                                                ║
║    dashboard.py          — Streamlit UI                      ║
║    main.py               — FastAPI backend                   ║
║    trikala_rf_model.pkl  — Trained model                     ║
║    trikala_encodings.json— City/Industry maps                ║
║    predictions.db        — SQLite history                    ║
╚══════════════════════════════════════════════════════════════╝
""")
